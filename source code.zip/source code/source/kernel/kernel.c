/*
 * kernel.c - ParenOS kernel main entry point.
 *
 * The kernel:
 *   1. Initializes the multiboot2 info (framebuffer, initramfs module)
 *   2. Sets up GDT/IDT/PIC/PIT
 *   3. Initializes the heap and console
 *   4. Loads the compiled ParenCode bytecode (program.bin) from the
 *      initramfs tar archive and runs it via the ParenCode VM.
 */
#include "parenos.h"
#include "vm.h"
#include "tar.h"
#include "shell.h"
#include "fb.h"
#include "ps2.h"
#include "pci.h"
#include "rtc.h"
#include "beep.h"
#include "wm.h"
#include "font.h"

static const char *g_banner =
    "\n"
    "================================================\n"
    "   ParenOS  v1.0   (c) 2026 ParenOS Project\n"
    "================================================\n"
    "Source language: ParenCode\n"
    "Source characters: + / ( )\n"
    "\n";

void kmain(uint64_t mb2_info) {
    /* 1. Parse multiboot2 info: framebuffer + modules */
    serial_init();
    mb2_parse(mb2_info);

    /* 2. CPU + interrupts */
    gdt_init();
    idt_init();
    pic_init();
    pit_init(100);              /* 100 Hz system tick */
    irq_disable();

    /* 3. Console on framebuffer */
    fb_init(mb2_info);
    fb_clear(0, 0, 0);
    fb_set_color(0xCCCCCC, 0x000000);

    /* 4. Heap: heap starts at _kernel_end and grows up. Reserve 16 MB. */
    extern char _kernel_end[];
    heap_init((void *)_kernel_end, 16 * 1024 * 1024);

    /* 5. Serial (for debugging) */
    serial_init();
    serial_write("ParenOS: serial ok\n", 19);

    /* 6. Print banner */
    fb_puts(g_banner);

    /* 7. Probe PCI bus (informational) */
    pci_scan();
    fb_puts("[kernel] PCI bus scan complete\n");

    /* 8. Init RTC */
    rtc_init();
    fb_puts("[kernel] RTC ok\n");

    /* 9. Mount initramfs (the .tar module loaded by GRUB) */
    if (!tar_init(mb2_get_module(NULL, NULL))) {
        fb_set_color(0xFF5555, 0x000000);
        fb_puts("[kernel] FATAL: no initramfs module found\n");
        kpanic("initramfs");
    }
    fb_puts("[kernel] initramfs mounted\n");

    /* 10. Load fonts from /system/fonts */
    font_init();
    fb_puts("[kernel] fonts loaded\n");

    /* 11. PS/2 keyboard + mouse */
    ps2_init();
    fb_puts("[kernel] PS/2 controller ready\n");

    /* 12. PC speaker (beep) */
    beep_init();
    fb_puts("[kernel] PC speaker ready\n");

    /* 13. Find /boot/program.bin (the compiled ParenCode entry) */
    size_t prog_size = 0;
    const uint8_t *prog = tar_lookup("/boot/program.bin", &prog_size);
    if (prog && prog_size > 0) {
        fb_puts("[kernel] launching ParenCode program (");
        fb_putuint(prog_size);
        fb_puts(" bytes)\n\n");
        vm_run(prog, prog_size);
    } else {
        fb_set_color(0xFFAA00, 0x000000);
        fb_puts("[kernel] WARNING: no /boot/program.bin in initramfs\n");
        fb_puts("[kernel]         Falling back to interactive shell.\n");
    }

    /* 14. Run the interactive shell (with window manager + apps) */
    shell_run();

    /* Should never reach here. */
    fb_set_color(0xFF5555, 0x000000);
    fb_puts("\n[kernel] shell exited. Halting.\n");
    kpanic("shell exit");
}

__attribute__((noreturn))
void kpanic(const char *msg) {
    irq_disable();
    fb_set_color(0xFF5555, 0x000000);
    fb_puts("\n*** KERNEL PANIC ***\n");
    if (msg) {
        fb_puts(msg);
        fb_newline();
    }
    fb_puts("System halted.\n");
    for (;;) {
        cpu_halt();
    }
}
