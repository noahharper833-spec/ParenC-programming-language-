/*
 * tar.c - USTAR initramfs parser.
 *
 * GRUB loads our initramfs (a tar archive) as a multiboot2 module.
 * We scan its USTAR headers in memory and answer tar_lookup() queries.
 *
 * Each USTAR header is 512 bytes. Files are padded to 512-byte blocks.
 */
#include "parenos.h"
#include "tar.h"

static const uint8_t *ramdisk_base = NULL;
static size_t         ramdisk_size = 0;

typedef struct {
    char name[100];
    char mode[8];
    char uid[8];
    char gid[8];
    char size[12];
    char mtime[12];
    char chksum[8];
    char typeflag;
    char linkname[100];
    char magic[6];
    char version[2];
    char uname[32];
    char gname[32];
    char devmajor[8];
    char devminor[8];
    char prefix[155];
    char pad[12];
} ustar_header_t;

static size_t tar_parse_oct(const char *s, int n) {
    size_t v = 0;
    for (int i = 0; i < n && s[i]; i++) {
        if (s[i] < '0' || s[i] > '7') break;
        v = v * 8 + (s[i] - '0');
    }
    return v;
}

int tar_init(const void *ramdisk) {
    ramdisk_base = (const uint8_t *)ramdisk;
    if (!ramdisk_base) return 0;
    /* First header should have a USTAR magic. */
    const ustar_header_t *h = (const ustar_header_t *)ramdisk_base;
    if (kstrncmp(h->magic, "ustar", 5) != 0) {
        /* Not USTAR - but we'll still try to scan since some tars
         * omit the magic for old-format. */
    }
    return 1;
}

const void *tar_lookup(const char *path, size_t *out_size) {
    if (!ramdisk_base) return NULL;
    const uint8_t *p = ramdisk_base;
    while (1) {
        const ustar_header_t *h = (const ustar_header_t *)p;
        if (h->name[0] == 0) break;
        size_t size = tar_parse_oct(h->size, sizeof(h->size));
        /* Skip PAX header entries (type 'g' or 'x') and "./PaxHeader" dirs. */
        char tf = h->typeflag;
        const char *name = h->name;
        int is_pax = (tf == 'g' || tf == 'x' ||
                      kstrncmp(name, "./PaxHeader", 11) == 0 ||
                      kstrncmp(name, "PaxHeader", 9) == 0);
        if (!is_pax) {
            /* Strip leading "./" */
            if (name[0] == '.' && name[1] == '/') name += 2;
            const char *path2 = path;
            if (path2[0] == '/') path2++;
            if (kstrcmp(name, path2) == 0) {
                if (out_size) *out_size = size;
                return p + 512;
            }
        }
        /* Skip header + data, padded to 512 bytes. */
        size_t blocks = (size + 511) / 512 + 1;
        p += blocks * 512;
        /* Sanity check: don't walk off the end. */
        if (p == ramdisk_base) break;
    }
    return NULL;
}

void tar_enumerate(void (*cb)(const char *path, size_t size, void *u), void *u) {
    if (!ramdisk_base) return;
    const uint8_t *p = ramdisk_base;
    while (1) {
        const ustar_header_t *h = (const ustar_header_t *)p;
        if (h->name[0] == 0) break;
        size_t size = tar_parse_oct(h->size, sizeof(h->size));
        char tf = h->typeflag;
        const char *name = h->name;
        int is_pax = (tf == 'g' || tf == 'x' ||
                      kstrncmp(name, "./PaxHeader", 11) == 0 ||
                      kstrncmp(name, "PaxHeader", 9) == 0);
        if (!is_pax) {
            if (name[0] == '.' && name[1] == '/') name += 2;
            /* Skip directory entries (trailing '/') - we just want files. */
            if (tf != '5') {
                cb(name, size, u);
            }
        }
        size_t blocks = (size + 511) / 512 + 1;
        p += blocks * 512;
        if (p == ramdisk_base) break;
    }
}
