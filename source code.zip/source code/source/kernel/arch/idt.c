/*
 * idt.c - Interrupt Descriptor Table (long mode).
 *
 * We install 256 interrupt gates. IRQs 0x20..0x2F are remapped from
 * the 8259 PIC. Each gate points to a tiny stub in idt_stubs.S that
 * pushes the IRQ number and calls idt_dispatch().
 */
#include "parenos.h"

struct __attribute__((packed)) idt_entry {
    uint16_t base_low;
    uint16_t selector;
    uint8_t  ist;
    uint8_t  type_attr;
    uint16_t base_mid;
    uint32_t base_high;
    uint32_t zero;
};

struct __attribute__((packed)) idt_ptr {
    uint16_t limit;
    uint64_t base;
};

static struct idt_entry idt[256] __attribute__((aligned(16)));
static struct idt_ptr      idt_ptr_;

/* IRQ handlers defined in idt_stubs.S */
extern void idt_stub_0(void);
extern void idt_stub_3(void);   /* int 3 */
extern void idt_stub_6(void);   /* invalid opcode */
extern void idt_stub_8(void);   /* double fault */
extern void idt_stub_13(void);  /* GPF */
extern void idt_stub_14(void);  /* page fault */
extern void idt_stub_32(void);  /* PIT  */
extern void idt_stub_33(void);  /* KBD  */
extern void idt_stub_34(void);  /* COM1 */
extern void idt_stub_44(void);  /* mouse (IRQ12) */

static void idt_set_entry(int n, void (*handler)(void), uint8_t type) {
    uint64_t addr = (uint64_t)handler;
    idt[n].base_low  = addr & 0xFFFF;
    idt[n].selector  = 0x08;
    idt[n].ist       = 0;
    idt[n].type_attr = type;
    idt[n].base_mid  = (addr >> 16) & 0xFFFF;
    idt[n].base_high = (addr >> 32) & 0xFFFFFFFF;
    idt[n].zero      = 0;
}

void idt_init(void) {
    kmemset(idt, 0, sizeof(idt));
    /* CPU exceptions */
    idt_set_entry(3,  idt_stub_3,  0x8E);
    idt_set_entry(6,  idt_stub_6,  0x8E);
    idt_set_entry(8,  idt_stub_8,  0x8E);
    idt_set_entry(13, idt_stub_13, 0x8E);
    idt_set_entry(14, idt_stub_14, 0x8E);
    /* IRQs */
    idt_set_entry(32, idt_stub_32, 0x8E);
    idt_set_entry(33, idt_stub_33, 0x8E);
    idt_set_entry(34, idt_stub_34, 0x8E);
    idt_set_entry(44, idt_stub_44, 0x8E);
    idt_ptr_.limit = sizeof(idt) - 1;
    idt_ptr_.base  = (uint64_t)&idt;
    __asm__ volatile ("lidt %0" :: "m"(idt_ptr_));
}

/* Called from idt_stubs.S with the IRQ number in rdi. */
void idt_dispatch(uint64_t irq_no) {
    switch (irq_no) {
    case 32: pit_handler();          return; /* timer */
    case 33: kbd_handler();          return; /* keyboard */
    case 34: serial_handler();       return; /* COM1 */
    case 44: mouse_handler();        return; /* mouse */
    case 3:  kpanic("int3");         return;
    case 6:  kpanic("invalid opcode");
    case 8:  kpanic("double fault");
    case 13: kpanic("general protection fault");
    case 14: kpanic("page fault");
    default: kpanic("unknown IRQ");
    }
}
