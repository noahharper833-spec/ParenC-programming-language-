/*
 * pic.c - 8259 Programmable Interrupt Controller setup.
 * We remap the master+slave PICs to IRQs 32..47.
 */
#include "parenos.h"

#define PIC1  0x20
#define PIC2  0xA0
#define PIC1_CMD  PIC1
#define PIC1_DATA (PIC1 + 1)
#define PIC2_CMD  PIC2
#define PIC2_DATA (PIC2 + 1)
#define PIC_EOI  0x20

void pic_init(void) {
    /* ICW1: start init, cascade, expect ICW4 */
    outb(PIC1_CMD, 0x11);
    outb(PIC2_CMD, 0x11);
    /* ICW2: vector offsets */
    outb(PIC1_DATA, 0x20);   /* master IRQ 0..7 -> 0x20..0x27 */
    outb(PIC2_DATA, 0x28);   /* slave  IRQ 8..15 -> 0x28..0x2F */
    /* ICW3: tell master that slave is on IRQ2; tell slave its cascade ID is 2 */
    outb(PIC1_DATA, 0x04);
    outb(PIC2_DATA, 0x02);
    /* ICW4: 8086 mode */
    outb(PIC1_DATA, 0x01);
    outb(PIC2_DATA, 0x01);
    /* Mask all IRQs initially (we'll unmask the ones we use) */
    outb(PIC1_DATA, 0xFB);   /* unmask IRQ2 (cascade) only */
    outb(PIC2_DATA, 0xFF);
}

void pic_mask(int irq) {
    uint16_t port = irq < 8 ? PIC1_DATA : PIC2_DATA;
    uint8_t  val  = inb(port);
    val |= 1 << (irq & 7);
    outb(port, val);
}

void pic_unmask(int irq) {
    uint16_t port = irq < 8 ? PIC1_DATA : PIC2_DATA;
    uint8_t  val  = inb(port);
    val &= ~(1 << (irq & 7));
    outb(port, val);
}

void pic_eoi(int irq) {
    if (irq >= 8) outb(PIC2_CMD, PIC_EOI);
    outb(PIC1_CMD, PIC_EOI);
}

void irq_enable(void)  { __asm__ volatile ("sti"); }
void irq_disable(void) { __asm__ volatile ("cli"); }

void irq_eoi(int irq) { pic_eoi(irq); }
