/*
 * mb2.c - multiboot2 info tag parser.
 *
 * We extract:
 *   - framebuffer info (tag type 8)
 *   - the first module (tag type 3) — our initramfs tar
 */
#include "parenos.h"

extern framebuffer_t g_fb;

static const void   *g_module_start = NULL;
static uint64_t      g_module_size  = 0;

void mb2_parse(uint64_t mb2_info) {
    if (mb2_info == 0) {
        serial_write("ParenOS: no multiboot2 info\n", 28);
        return;
    }
    uint8_t *p = (uint8_t *)mb2_info;
    uint32_t total = *(uint32_t *)p;
    uint8_t *end   = p + total;
    p += 8; /* skip total_size + reserved */
    while (p + 8 <= end) {
        uint16_t type   = *(uint16_t *)p;
        uint16_t flags  = *(uint16_t *)(p + 2);
        (void)flags;
        uint32_t size   = *(uint32_t *)(p + 4);
        if (size == 0) break;
        uint8_t *data   = p + 8;
        if (type == 8) {
            /* Framebuffer info - multiboot2 spec layout:
             *   u64 framebuffer_addr      (offset 0)
             *   u32 framebuffer_pitch     (offset 8)
             *   u32 framebuffer_width     (offset 12)
             *   u32 framebuffer_height    (offset 16)
             *   u8  framebuffer_bpp       (offset 20)
             *   u8  framebuffer_type     (offset 21)
             *   u8  color_info[variable] (offset 22+)
             */
            uint64_t addr    = *(uint64_t *)(data + 0);
            uint32_t pitch   = *(uint32_t *)(data + 8);
            uint32_t width   = *(uint32_t *)(data + 12);
            uint32_t height  = *(uint32_t *)(data + 16);
            uint8_t  bpp     = *(uint8_t *) (data + 20);
            uint8_t  fbtype  = *(uint8_t *) (data + 21);
            g_fb.buf     = (uint32_t *)(uintptr_t)addr;
            g_fb.width   = width;
            g_fb.height  = height;
            g_fb.pitch   = pitch;
            g_fb.bpp     = bpp;
            g_fb.type    = fbtype;
            if (fbtype == 1) {
                /* RGB framebuffer. Color info follows. */
                uint8_t *fields = data + 22;
                uint8_t rpos = fields[0], rmask = fields[1];
                uint8_t gpos = fields[2], gmask = fields[3];
                uint8_t bpos = fields[4], bmask = fields[5];
                (void)rmask; (void)gmask; (void)bmask;
                g_fb.r_pos = rpos; g_fb.g_pos = gpos; g_fb.b_pos = bpos;
            } else if (fbtype == 2) {
                /* EGA-style text mode: 2 bytes per cell (char + attr). */
                g_fb.type = 2;
            } else {
                g_fb.r_pos = 16; g_fb.g_pos = 8; g_fb.b_pos = 0;
            }
        } else if (type == 3) {
            /* Module */
            uint64_t mod_start = *(uint32_t *)(data + 0);
            uint64_t mod_end   = *(uint32_t *)(data + 4);
            g_module_start = (const void *)(uintptr_t)mod_start;
            g_module_size  = mod_end - mod_start;
        }
        /* Align to 8 bytes */
        size = (size + 7) & ~7u;
        p += size;
    }
}

const framebuffer_t *mb2_get_framebuffer(void) {
    return &g_fb;
}

const void *mb2_get_module(uint64_t *out_size, const char *name_prefix) {
    (void)name_prefix; /* currently unused: just return the first module */
    if (out_size) *out_size = g_module_size;
    return g_module_start;
}
