/*
 * gdt.c - GDT for the running kernel (long mode).
 * We re-load a kernel-only GDT for cleanliness after the boot stub's
 * GDT. No user segments yet (ring 0 only).
 */
#include "parenos.h"

static struct __attribute__((packed)) gdt_entry {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  granularity;
    uint8_t  base_high;
} gdt[3];

static struct __attribute__((packed)) gdt_ptr {
    uint16_t limit;
    uint64_t base;
} gdt_ptr_;

static void gdt_set(int i, uint32_t base, uint32_t limit, uint8_t access, uint8_t gran) {
    gdt[i].limit_low  = limit & 0xFFFF;
    gdt[i].base_low   = base & 0xFFFF;
    gdt[i].base_mid   = (base >> 16) & 0xFF;
    gdt[i].access     = access;
    gdt[i].granularity = ((limit >> 16) & 0x0F) | (gran & 0xF0);
    gdt[i].base_high  = (base >> 24) & 0xFF;
}

void gdt_init(void) {
    gdt_set(0, 0, 0, 0, 0);
    gdt_set(1, 0, 0xFFFFF, 0x9A, 0xA0);   /* code: long mode */
    gdt_set(2, 0, 0xFFFFF, 0x92, 0xA0);   /* data */
    gdt_ptr_.limit = sizeof(gdt) - 1;
    gdt_ptr_.base  = (uint64_t)&gdt;
    __asm__ volatile (
        "lgdt %0\n"
        "mov $0x10, %%ax\n"
        "mov %%ax, %%ds\n"
        "mov %%ax, %%es\n"
        "mov %%ax, %%fs\n"
        "mov %%ax, %%gs\n"
        "mov %%ax, %%ss\n"
        "pushq $0x08\n"
        "leaq 1f(%%rip), %%rax\n"
        "pushq %%rax\n"
        "lretq\n"
        "1:\n"
        :: "m"(gdt_ptr_) : "rax"
    );
}
