/*
 * heap.c - simple bump allocator with free-list.
 *
 * The heap region starts at _kernel_end and is sized at heap_init time.
 * Allocations below HEAP_THRESHOLD use a free-list; above threshold we
 * just bump-allocate (we don't free those). This is enough for a small
 * kernel like ParenOS.
 */
#include "parenos.h"

#define HEAP_ALIGN 16

typedef struct heap_block {
    size_t size;
    int    free;
    struct heap_block *next;
} heap_block_t;

static uint8_t  *heap_start = NULL;
static size_t    heap_size  = 0;
static size_t    heap_used  = 0;
static heap_block_t *free_list = NULL;

void heap_init(void *start, size_t size) {
    heap_start = (uint8_t *)(((uintptr_t)start + HEAP_ALIGN - 1) & ~((uintptr_t)HEAP_ALIGN - 1));
    heap_size  = size;
    heap_used  = 0;
    free_list  = (heap_block_t *)heap_start;
    free_list->size = size - sizeof(heap_block_t);
    free_list->free = 1;
    free_list->next = NULL;
}

void *kmalloc(size_t n) {
    if (n == 0) return NULL;
    n = (n + HEAP_ALIGN - 1) & ~((size_t)HEAP_ALIGN - 1);
    for (heap_block_t *b = free_list; b; b = b->next) {
        if (b->free && b->size >= n) {
            if (b->size >= n + sizeof(heap_block_t) + HEAP_ALIGN) {
                /* split */
                heap_block_t *nb = (heap_block_t *)((uint8_t *)b + sizeof(heap_block_t) + n);
                nb->size = b->size - n - sizeof(heap_block_t);
                nb->free = 1;
                nb->next = b->next;
                b->next  = nb;
                b->size  = n;
            }
            b->free = 0;
            heap_used += n + sizeof(heap_block_t);
            return (void *)((uint8_t *)b + sizeof(heap_block_t));
        }
    }
    return NULL;
}

void *kzalloc(size_t n) {
    void *p = kmalloc(n);
    if (p) kmemset(p, 0, n);
    return p;
}

void kfree(void *p) {
    if (!p) return;
    heap_block_t *b = (heap_block_t *)((uint8_t *)p - sizeof(heap_block_t));
    b->free = 1;
    /* coalesce with next */
    if (b->next && b->next->free) {
        b->size += sizeof(heap_block_t) + b->next->size;
        b->next  = b->next->next;
    }
    /* coalesce with previous (linear scan) */
    for (heap_block_t *p2 = free_list; p2; p2 = p2->next) {
        if (p2->free && p2->next == b && b->free) {
            p2->size += sizeof(heap_block_t) + b->size;
            p2->next  = b->next;
            break;
        }
    }
}

void kmemset(void *p, int v, size_t n) {
    uint8_t *d = (uint8_t *)p;
    while (n--) *d++ = (uint8_t)v;
}

void kmemcpy(void *dst, const void *src, size_t n) {
    uint8_t *d = (uint8_t *)dst;
    const uint8_t *s = (const uint8_t *)src;
    while (n--) *d++ = *s++;
}

size_t kstrlen(const char *s) {
    size_t n = 0;
    while (s[n]) n++;
    return n;
}

int kstrcmp(const char *a, const char *b) {
    while (*a && *a == *b) { a++; b++; }
    return (int)(unsigned char)*a - (int)(unsigned char)*b;
}

int kstrncmp(const char *a, const char *b, size_t n) {
    while (n && *a && *a == *b) { a++; b++; n--; }
    if (n == 0) return 0;
    return (int)(unsigned char)*a - (int)(unsigned char)*b;
}

char *kstrcpy(char *dst, const char *src) {
    char *r = dst;
    while ((*dst++ = *src++));
    return r;
}

char *kstrcat(char *dst, const char *src) {
    char *r = dst + kstrlen(dst);
    while ((*r++ = *src++));
    return dst;
}

char *kstrncpy(char *dst, const char *src, size_t n) {
    size_t i = 0;
    while (i < n && src[i]) { dst[i] = src[i]; i++; }
    while (i < n) { dst[i++] = 0; }
    return dst;
}

int kstoi(const char *s, char **end) {
    int sign = 1, v = 0;
    while (*s == ' ' || *s == '\t') s++;
    if (*s == '-') { sign = -1; s++; }
    else if (*s == '+') s++;
    while (*s >= '0' && *s <= '9') {
        v = v * 10 + (*s - '0');
        s++;
    }
    if (end) *end = (char *)s;
    return v * sign;
}
