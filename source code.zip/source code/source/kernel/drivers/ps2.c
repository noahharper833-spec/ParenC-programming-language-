/*
 * ps2.c - PS/2 controller, keyboard, and mouse driver.
 *
 * We use the legacy 8042 controller on ports 0x60 (data) and 0x64 (status).
 * IRQ1 (vector 33) is the keyboard; IRQ12 (vector 44) is the mouse.
 *
 * Scancodes are translated to ASCII via set 1 lookup table.
 *
 * Mouse packets are 3 bytes: [flags, x, y] (PS/2 mouse with no wheel).
 */
#include "parenos.h"
#include "ps2.h"

#define PS2_DATA  0x60
#define PS2_STAT  0x64
#define PS2_CMD   0x64

/* Keyboard ring buffer */
static volatile uint8_t  kbd_buf[256];
static volatile uint32_t kbd_head = 0, kbd_tail = 0;
static int               shift = 0;

/* Set 1 scancode -> ASCII */
static const uint8_t scancode_map[128] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=', 8, 9,
    'q','w','e','r','t','y','u','i','o','p','[',']', 13, 0,
    'a','s','d','f','g','h','j','k','l',';','\'','`', 0,
    '\\','z','x','c','v','b','n','m',',','.','/', 0, '*', 0, ' ',
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '-', 0, 0, 0, '+', 0, 0, 0, 0, 0,
};
static const uint8_t scancode_shift_map[128] = {
    0, 27, '!','@','#','$','%','^','&','*','(',')','_','+', 8, 9,
    'Q','W','E','R','T','Y','U','I','O','P','{','}', 13, 0,
    'A','S','D','F','G','H','J','K','L',':','"','~', 0,
    '|','Z','X','C','V','B','N','M','<','>','?', 0, '*', 0, ' ',
};

/* Mouse state */
static volatile int32_t  mouse_x = 400, mouse_y = 300;
static volatile uint8_t  mouse_flags = 0;
static volatile uint8_t  mouse_btn  = 0;
static volatile int      mouse_phase = 0;
static volatile uint8_t  mouse_packet[3];

/* Pending mouse event for userspace */
static volatile bool     mouse_event_pending = false;

void ps2_init(void) {
    /* Disable both ports */
    outb(PS2_CMD, 0xAD);
    outb(PS2_CMD, 0xA7);
    /* Flush output */
    while (inb(PS2_STAT) & 1) (void)inb(PS2_DATA);
    /* Controller config */
    outb(PS2_CMD, 0x20);
    while (!(inb(PS2_STAT) & 1));
    uint8_t cfg = inb(PS2_DATA);
    cfg |= 0x01 | 0x02;   /* enable IRQ1 + IRQ12 */
    cfg &= ~0x40;          /* enable translation */
    outb(PS2_CMD, 0x60);
    while (inb(PS2_STAT) & 2);
    outb(PS2_DATA, cfg);
    /* Controller self-test */
    outb(PS2_CMD, 0xAA);
    while (!(inb(PS2_STAT) & 1));
    if (inb(PS2_DATA) != 0x55) {
        /* controller test failed - we'll continue anyway */
    }
    /* Test first port */
    outb(PS2_CMD, 0xAB);
    while (!(inb(PS2_STAT) & 1));
    (void)inb(PS2_DATA);
    /* Enable first port */
    outb(PS2_CMD, 0xAE);
    /* Reset keyboard */
    outb(PS2_DATA, 0xFF);
    while (!(inb(PS2_STAT) & 1));
    (void)inb(PS2_DATA);   /* ACK */
    /* Set scancode set 1 */
    outb(PS2_DATA, 0xF0);
    while (!(inb(PS2_STAT) & 1)); (void)inb(PS2_DATA);
    outb(PS2_DATA, 0x01);
    while (!(inb(PS2_STAT) & 1)); (void)inb(PS2_DATA);
    /* Enable scanning */
    outb(PS2_DATA, 0xF4);
    while (!(inb(PS2_STAT) & 1)); (void)inb(PS2_DATA);

    /* Mouse: enable aux port */
    outb(PS2_CMD, 0xA8);
    /* Get mouse ID */
    outb(PS2_CMD, 0xD4);
    while (inb(PS2_STAT) & 2);
    outb(PS2_DATA, 0xF2);
    while (!(inb(PS2_STAT) & 1)); (void)inb(PS2_DATA);
    /* Set defaults */
    outb(PS2_CMD, 0xD4);
    while (inb(PS2_STAT) & 2);
    outb(PS2_DATA, 0xF6);
    while (!(inb(PS2_STAT) & 1)); (void)inb(PS2_DATA);
    /* Enable streaming */
    outb(PS2_CMD, 0xD4);
    while (inb(PS2_STAT) & 2);
    outb(PS2_DATA, 0xF4);
    while (!(inb(PS2_STAT) & 1)); (void)inb(PS2_DATA);

    /* Unmask IRQ1 + IRQ12 */
    pic_unmask(1);
    pic_unmask(12);
}

void kbd_handler(void) {
    uint8_t sc = inb(PS2_DATA);
    if (sc == 0x2A || sc == 0x36) shift = 1;
    else if (sc == 0xAA || sc == 0xB6) shift = 0;
    else if (sc & 0x80) {
        /* key release - ignore for now */
    } else {
        uint8_t c = shift ? scancode_shift_map[sc] : scancode_map[sc];
        if (c) {
            kbd_buf[kbd_tail] = c;
            kbd_tail = (kbd_tail + 1) % 256;
        }
    }
    pic_eoi(1);
}

int kbd_getc(void) {
    if (kbd_head == kbd_tail) return -1;
    uint8_t c = kbd_buf[kbd_head];
    kbd_head = (kbd_head + 1) % 256;
    return c;
}

int kbd_waitc(void) {
    int c;
    while ((c = kbd_getc()) < 0) {
        __asm__ volatile ("hlt");
    }
    return c;
}

void mouse_handler(void) {
    uint8_t b = inb(PS2_DATA);
    switch (mouse_phase) {
    case 0:
        if (b & 0x08) {
            mouse_packet[0] = b;
            mouse_phase = 1;
        }
        break;
    case 1:
        mouse_packet[1] = b;
        mouse_phase = 2;
        break;
    case 2:
        mouse_packet[2] = b;
        mouse_phase = 0;
        mouse_flags = mouse_packet[0];
        mouse_btn   = mouse_flags & 0x07;
        int dx = (int8_t)mouse_packet[1];
        int dy = (int8_t)mouse_packet[2];
        mouse_x += dx;
        mouse_y -= dy;        /* PS/2 reports Y downward; we want Y up */
        if (mouse_x < 0) mouse_x = 0;
        if (mouse_y < 0) mouse_y = 0;
        if ((uint32_t)mouse_x >= g_fb.width)  mouse_x = g_fb.width  - 1;
        if ((uint32_t)mouse_y >= g_fb.height) mouse_y = g_fb.height - 1;
        mouse_event_pending = true;
        break;
    }
    pic_eoi(12);
}

int mouse_get_x(void)        { return mouse_x; }
int mouse_get_y(void)        { return mouse_y; }
uint8_t mouse_get_btn(void)  { return mouse_btn; }
bool mouse_poll_event(int *x, int *y, uint8_t *btn) {
    if (!mouse_event_pending) return false;
    *x = mouse_x; *y = mouse_y; *btn = mouse_btn;
    mouse_event_pending = false;
    return true;
}
