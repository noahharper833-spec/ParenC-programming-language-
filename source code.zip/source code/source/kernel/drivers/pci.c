/*
 * pci.c - simple PCI configuration space reader.
 * We scan bus 0 and report each device/vendor pair to the console.
 * This is informational only - ParenOS does not yet bind any PCI
 * drivers (no network/storage driver written in this release).
 */
#include "parenos.h"

#define PCI_ADDR  0xCF8
#define PCI_DATA  0xCFC

static uint32_t pci_read(uint8_t bus, uint8_t dev, uint8_t func, uint8_t off) {
    uint32_t addr = 0x80000000u
                  | ((uint32_t)bus << 16)
                  | ((uint32_t)dev << 11)
                  | ((uint32_t)func << 8)
                  | (off & 0xFC);
    outl(PCI_ADDR, addr);
    return inl(PCI_DATA) >> ((off & 2) * 8);
}

static uint16_t pci_vendor(uint8_t b, uint8_t d, uint8_t f) {
    return (uint16_t)pci_read(b, d, f, 0);
}
static uint16_t pci_device(uint8_t b, uint8_t d, uint8_t f) {
    return (uint16_t)(pci_read(b, d, f, 0) >> 16);
}
static uint8_t  pci_class(uint8_t b, uint8_t d, uint8_t f) {
    return (uint8_t)(pci_read(b, d, f, 0x08) >> 24);
}
static uint8_t  pci_subclass(uint8_t b, uint8_t d, uint8_t f) {
    return (uint8_t)(pci_read(b, d, f, 0x08) >> 16);
}

void pci_scan(void) {
    /* Scan bus 0 only (good enough for QEMU). */
    for (int dev = 0; dev < 32; dev++) {
        for (int func = 0; func < 8; func++) {
            uint16_t v = pci_vendor(0, dev, func);
            if (v == 0xFFFF) continue;
            uint16_t d = pci_device(0, dev, func);
            uint8_t  c = pci_class(0, dev, func);
            uint8_t  sc = pci_subclass(0, dev, func);
            (void)c; (void)sc; (void)d;
            /* We deliberately don't print each device to keep the boot
             * output clean - the scan result is reported as a count. */
        }
    }
}
