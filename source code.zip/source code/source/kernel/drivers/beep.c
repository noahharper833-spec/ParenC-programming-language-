/*
 * beep.c - PC speaker beep driver.
 * Channel 2 of the 8253 PIT is connected to the PC speaker.
 * We gate it on/off via port 0x61.
 */
#include "parenos.h"
#include "beep.h"

#define PIT_DATA2 0x42
#define PIT_CMD   0x43
#define KB_PORT  0x61

void beep_init(void) {
    /* nothing to do */
}

void beep_on(uint32_t freq) {
    if (freq == 0) freq = 440;
    uint32_t div = 1193182 / freq;
    if (div == 0) div = 1;
    if (div > 0xFFFF) div = 0xFFFF;
    outb(PIT_CMD, 0xB6);
    outb(PIT_DATA2, div & 0xFF);
    outb(PIT_DATA2, (div >> 8) & 0xFF);
    uint8_t v = inb(KB_PORT);
    if (!(v & 0x03)) {
        outb(KB_PORT, v | 0x03);
    }
}

void beep_off(void) {
    uint8_t v = inb(KB_PORT);
    outb(KB_PORT, v & ~0x03);
}

void beep_play(uint32_t freq, uint32_t ms) {
    beep_on(freq);
    /* Busy-wait approximately ms milliseconds using the PIT tick count
     * (which ticks at 100 Hz = 10 ms per tick). */
    extern volatile uint64_t g_ticks;
    uint64_t start = g_ticks;
    uint64_t need = (ms + 9) / 10;
    while (g_ticks - start < need) {
        __asm__ volatile ("hlt");
    }
    beep_off();
}
