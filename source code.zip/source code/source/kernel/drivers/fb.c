/*
 * fb.c - VBE framebuffer driver and a simple text console on top.
 *
 * GRUB sets a VBE mode (typically 800x600 or 1024x768 32bpp) and
 * passes the framebuffer address/geometry via multiboot2. We write
 * 32-bit RGB pixels directly to it.
 *
 * The text console uses an 8x16 bitmap font (see font.c). We keep a
 * text cursor (cx,cy) and a current fg/bg color.
 */
#include "parenos.h"
#include "font.h"

framebuffer_t g_fb = {0};

static int      con_cx = 0, con_cy = 0;
static uint32_t con_fg = 0xCCCCCC;
static uint32_t con_bg = 0x000000;
static bool     fb_inited = false;

static inline uint32_t pack_color(uint8_t r, uint8_t g, uint8_t b) {
    /* Standard 32bpp RGB: red at 16, green at 8, blue at 0. */
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

uint32_t fb_make_color(uint8_t r, uint8_t g, uint8_t b) {
    return pack_color(r, g, b);
}

/* Convert a 24-bit RGB color to a VGA text-mode attribute byte.
 * VGA text mode uses 16 colors: 8 background (no bright) and 16 foreground.
 */
static uint8_t vga_attr_from_rgb(uint32_t fg, uint32_t bg) {
    /* crude 24-bit RGB -> 4-bit VGA color */
    static const uint8_t vga_palette[16] = {
        0,  /* black */
        1,  /* blue */
        2,  /* green */
        3,  /* cyan */
        4,  /* red */
        5,  /* magenta */
        6,  /* brown */
        7,  /* light gray */
        8,  /* dark gray */
        9,  /* bright blue */
        10, /* bright green */
        11, /* bright cyan */
        12, /* bright red */
        13, /* bright magenta */
        14, /* yellow */
        15, /* white */
    };
    /* Map 24-bit to closest VGA color (very approximate). */
    int r = (fg >> 16) & 0xFF;
    int g = (fg >> 8) & 0xFF;
    int b = fg & 0xFF;
    int fg_vga = 7;
    int bright = (r > 0x80 || g > 0x80 || b > 0x80) ? 8 : 0;
    if (r > 0x60 && r > g && r > b) fg_vga = 4;
    else if (g > 0x60 && g > r && g > b) fg_vga = 2;
    else if (b > 0x60 && b > r && b > g) fg_vga = 1;
    else if (r > 0x60 && g > 0x60) fg_vga = 6;
    else if (r > 0x60 && b > 0x60) fg_vga = 5;
    else if (g > 0x60 && b > 0x60) fg_vga = 3;
    fg_vga |= bright;
    (void)vga_palette;

    /* Map background (no bright bit) */
    r = (bg >> 16) & 0xFF;
    g = (bg >> 8) & 0xFF;
    b = bg & 0xFF;
    int bg_vga = 0;
    if (r > 0x80 && r > g && r > b) bg_vga = 4;
    else if (g > 0x80 && g > r && g > b) bg_vga = 2;
    else if (b > 0x80 && b > r && b > g) bg_vga = 1;
    else if (r > 0x80 && g > 0x80) bg_vga = 6;
    else if (r > 0x80 && b > 0x80) bg_vga = 5;
    else if (g > 0x80 && b > 0x80) bg_vga = 3;
    else if (r > 0x80 || g > 0x80 || b > 0x80) bg_vga = 7;

    return (uint8_t)((bg_vga << 4) | (fg_vga & 0x0F));
}

void fb_init(uint64_t mb2_info) {
    (void)mb2_info;
    fb_inited = (g_fb.buf != NULL);
    if (fb_inited) {
        con_cx = 0; con_cy = 0;
    }
}

void fb_clear(uint8_t r, uint8_t g, uint8_t b) {
    if (!fb_inited) return;
    if (g_fb.type == 2) {
        /* Text mode: clear with spaces + attribute. */
        uint8_t attr = vga_attr_from_rgb(con_fg, pack_color(r, g, b));
        uint16_t cell = (' ' | (attr << 8));
        uint16_t *p = (uint16_t *)g_fb.buf;
        uint32_t n = (g_fb.pitch / 2) * g_fb.height;
        for (uint32_t i = 0; i < n; i++) p[i] = cell;
    } else {
        uint32_t c = pack_color(r, g, b);
        uint32_t *p = g_fb.buf;
        uint32_t n = (g_fb.pitch / 4) * g_fb.height;
        for (uint32_t i = 0; i < n; i++) p[i] = c;
    }
    con_cx = 0; con_cy = 0;
}

void fb_set_color(uint32_t fg, uint32_t bg) {
    con_fg = fg; con_bg = bg;
}

void fb_set_cursor(int x, int y) {
    con_cx = x; con_cy = y;
}

int fb_cols(void) {
    if (g_fb.type == 2) return g_fb.width;   /* in text mode width is in cells */
    return g_fb.width  / 8;
}
int fb_rows(void) {
    if (g_fb.type == 2) return g_fb.height;
    return g_fb.height / 16;
}

static void fb_text_putc(int x, int y, char c) {
    uint8_t attr = vga_attr_from_rgb(con_fg, con_bg);
    uint16_t cell = ((uint8_t)c) | (attr << 8);
    ((uint16_t *)g_fb.buf)[y * (g_fb.pitch / 2) + x] = cell;
}

void fb_newline(void) {
    con_cx = 0;
    con_cy++;
    if (con_cy >= fb_rows()) {
        fb_scroll(1);
        con_cy = fb_rows() - 1;
    }
}

void fb_backspace(void) {
    if (con_cx > 0) con_cx--;
    /* erase the cell */
    if (g_fb.type == 2) fb_text_putc(con_cx, con_cy, ' ');
    else font_draw_glyph(' ', con_cx * 8, con_cy * 16, con_fg, con_bg);
}

void fb_scroll(int lines) {
    if (lines <= 0 || !fb_inited) return;
    if (g_fb.type == 2) {
        /* Text mode scroll: 2 bytes per cell. */
        int pitch_cells = g_fb.pitch / 2;
        int visible_rows = fb_rows();
        if (lines > visible_rows) lines = visible_rows;
        for (int y = 0; y < visible_rows - lines; y++) {
            for (int x = 0; x < pitch_cells; x++) {
                ((uint16_t *)g_fb.buf)[y * pitch_cells + x] =
                    ((uint16_t *)g_fb.buf)[(y + lines) * pitch_cells + x];
            }
        }
        uint8_t attr = vga_attr_from_rgb(con_fg, con_bg);
        uint16_t cell = (' ' | (attr << 8));
        for (int y = visible_rows - lines; y < visible_rows; y++) {
            for (int x = 0; x < pitch_cells; x++) {
                ((uint16_t *)g_fb.buf)[y * pitch_cells + x] = cell;
            }
        }
        return;
    }
    int row_h = 16;
    int pitch_px = g_fb.pitch / 4;
    int visible_rows = fb_rows();
    if (lines > visible_rows) lines = visible_rows;
    for (int y = 0; y < visible_rows - lines; y++) {
        for (int x = 0; x < pitch_px; x++) {
            g_fb.buf[y * pitch_px + x] = g_fb.buf[(y + lines) * pitch_px + x];
        }
    }
    for (int y = visible_rows - lines; y < visible_rows; y++) {
        for (int x = 0; x < pitch_px; x++) {
            g_fb.buf[y * pitch_px + x] = con_bg;
        }
    }
}

void fb_putc(char c) {
    if (!fb_inited) {
        serial_putc(c);
        return;
    }
    if (c == '\n') { fb_newline(); return; }
    if (c == '\r') { con_cx = 0; return; }
    if (c == '\t') {
        con_cx = (con_cx + 8) & ~7;
        if (con_cx >= fb_cols()) fb_newline();
        return;
    }
    if (c == 8) { fb_backspace(); return; }
    if (g_fb.type == 2) {
        fb_text_putc(con_cx, con_cy, c);
    } else {
        font_draw_glyph(c, con_cx * 8, con_cy * 16, con_fg, con_bg);
    }
    con_cx++;
    if (con_cx >= fb_cols()) fb_newline();
}

void fb_puts(const char *s) {
    while (*s) fb_putc(*s++);
}

void fb_putdec(int64_t v) {
    char buf[24];
    int  i = 0;
    uint64_t u;
    if (v < 0) { fb_putc('-'); u = (uint64_t)(-v); } else u = (uint64_t)v;
    if (u == 0) buf[i++] = '0';
    while (u > 0) { buf[i++] = '0' + (u % 10); u /= 10; }
    while (i > 0) fb_putc(buf[--i]);
}

void fb_putuint(uint64_t v) {
    char buf[24];
    int  i = 0;
    if (v == 0) buf[i++] = '0';
    while (v > 0) { buf[i++] = '0' + (v % 10); v /= 10; }
    while (i > 0) fb_putc(buf[--i]);
}

void fb_puthex(uint64_t v) {
    static const char *hex = "0123456789ABCDEF";
    char buf[17];
    int i = 0;
    if (v == 0) buf[i++] = '0';
    while (v > 0) { buf[i++] = hex[v & 0xF]; v >>= 4; }
    fb_puts("0x");
    while (i > 0) fb_putc(buf[--i]);
}

/* ---- framebuffer drawing primitives ---- */

void fb_draw_pixel(int x, int y, uint32_t color) {
    if (!fb_inited) return;
    if (g_fb.type == 2) {
        /* In VGA text mode, drawing individual pixels is not supported.
         * Approximate: set the cell at (x/8, y/16) to a colored block. */
        int cell_x = x / 8;
        int cell_y = y / 16;
        if (cell_x < 0 || cell_y < 0) return;
        if ((uint32_t)cell_x >= g_fb.width) return;
        if ((uint32_t)cell_y >= g_fb.height) return;
        uint8_t attr = vga_attr_from_rgb(color, con_bg);
        ((uint16_t *)g_fb.buf)[cell_y * (g_fb.pitch / 2) + cell_x] = ('\xDB' | (attr << 8));
        return;
    }
    if (x < 0 || y < 0 || (uint32_t)x >= g_fb.width || (uint32_t)y >= g_fb.height) return;
    g_fb.buf[y * (g_fb.pitch / 4) + x] = color;
}

void fb_draw_hline(int x, int y, int w, uint32_t color) {
    for (int i = 0; i < w; i++) fb_draw_pixel(x + i, y, color);
}

void fb_draw_vline(int x, int y, int h, uint32_t color) {
    for (int i = 0; i < h; i++) fb_draw_pixel(x, y + i, color);
}

void fb_draw_rect(int x, int y, int w, int h, uint32_t color) {
    if (g_fb.type == 2) {
        /* Text mode: fill the cell range with a colored block char. */
        int x0 = x / 8;
        int y0 = y / 16;
        int w_cells = (w + 7) / 8;
        int h_cells = (h + 15) / 16;
        uint8_t attr = vga_attr_from_rgb(color, con_bg);
        uint16_t cell = ('\xDB' | (attr << 8));
        for (int dy = 0; dy < h_cells; dy++) {
            for (int dx = 0; dx < w_cells; dx++) {
                int cx = x0 + dx, cy = y0 + dy;
                if (cx < 0 || cy < 0 || (uint32_t)cx >= g_fb.width || (uint32_t)cy >= g_fb.height) continue;
                ((uint16_t *)g_fb.buf)[cy * (g_fb.pitch / 2) + cx] = cell;
            }
        }
        return;
    }
    for (int j = 0; j < h; j++) {
        for (int i = 0; i < w; i++) {
            fb_draw_pixel(x + i, y + j, color);
        }
    }
}

void fb_draw_text(int x, int y, const char *s, uint32_t fg, uint32_t bg) {
    if (g_fb.type == 2) {
        /* In text mode, render the string directly into the text buffer. */
        int orig_cx = x / 8;
        int cy = y / 16;
        int cx = orig_cx;
        uint8_t attr = vga_attr_from_rgb(fg, bg);
        while (*s) {
            if (*s == '\n') { cy++; cx = orig_cx; s++; continue; }
            if (cx >= 0 && cy >= 0 && (uint32_t)cx < g_fb.width && (uint32_t)cy < g_fb.height) {
                ((uint16_t *)g_fb.buf)[cy * (g_fb.pitch / 2) + cx] = ((uint8_t)*s) | (attr << 8);
            }
            cx++;
            s++;
        }
        return;
    }
    int orig_x = x;
    while (*s) {
        if (*s == '\n') { y += 16; x = orig_x; s++; continue; }
        font_draw_glyph(*s, x, y, fg, bg);
        x += 8;
        s++;
    }
}
