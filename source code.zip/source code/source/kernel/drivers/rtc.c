/*
 * rtc.c - CMOS RTC reader. Returns BCD-decoded date/time.
 */
#include "parenos.h"
#include "rtc.h"

#define RTC_PORT 0x70
#define RTC_DATA 0x71

static uint8_t rtc_read(uint8_t reg) {
    outb(RTC_PORT, reg);
    return inb(RTC_DATA);
}

static uint8_t bcd_to_bin(uint8_t b) {
    return (b >> 4) * 10 + (b & 0x0F);
}

void rtc_init(void) {
    uint8_t b = rtc_read(0x0B);
    if (!(b & 0x04)) {
        /* BCD mode - leave it as-is, we'll convert on read */
    }
}

void rtc_get(rtc_time_t *t) {
    /* Make sure we're not in the middle of an update. */
    while (rtc_read(0x0A) & 0x80);
    uint8_t s = rtc_read(0x00);
    uint8_t m = rtc_read(0x02);
    uint8_t h = rtc_read(0x04);
    uint8_t d = rtc_read(0x07);
    uint8_t mo = rtc_read(0x08);
    uint8_t y = rtc_read(0x09);
    uint8_t b = rtc_read(0x0B);
    if (!(b & 0x04)) {
        s = bcd_to_bin(s); m = bcd_to_bin(m); h = bcd_to_bin(h);
        d = bcd_to_bin(d); mo = bcd_to_bin(mo); y = bcd_to_bin(y);
    }
    t->sec = s; t->min = m; t->hour = h;
    t->day = d; t->month = mo; t->year = 2000 + y;
}
