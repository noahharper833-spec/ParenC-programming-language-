/*
 * serial.c - 16550 UART driver (COM1 = 0x3F8).
 * Used for kernel debug output. The Shell also routes some commands here.
 */
#include "parenos.h"

#define COM1 0x3F8

void serial_init(void) {
    outb(COM1 + 1, 0x00);    /* Disable all interrupts */
    outb(COM1 + 3, 0x80);    /* Enable DLAB */
    outb(COM1 + 0, 0x03);    /* Divisor low  (38400 baud) */
    outb(COM1 + 1, 0x00);    /* Divisor high */
    outb(COM1 + 3, 0x03);    /* 8 bits, no parity, one stop */
    outb(COM1 + 2, 0xC7);    /* Enable FIFO, clear, 14-byte threshold */
    outb(COM1 + 4, 0x0B);    /* IRQs enabled, RTS/DSR set */
}

static int serial_can_tx(void) {
    return inb(COM1 + 5) & 0x20;
}

static int serial_can_rx(void) {
    return inb(COM1 + 5) & 0x01;
}

void serial_putc(char c) {
    if (c == '\n') serial_putc('\r');
    while (!serial_can_tx());
    outb(COM1, (uint8_t)c);
}

char serial_getc(void) {
    while (!serial_can_rx());
    return (char)inb(COM1);
}

int serial_write(const char *buf, size_t n) {
    size_t i;
    for (i = 0; i < n; i++) serial_putc(buf[i]);
    return (int)i;
}

/* IRQ 4 (vector 0x24) handler. We drain the FIFO. */
void serial_handler(void) {
    while (serial_can_rx()) {
        (void)inb(COM1);
    }
    pic_eoi(4);
}
