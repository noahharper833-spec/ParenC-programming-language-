/*
 * pit.c - 8253 Programmable Interval Timer driver.
 * Channel 0 is connected to IRQ0 (vector 32 after PIC remap).
 * We configure it in mode 2 (rate generator) at a requested frequency.
 */
#include "parenos.h"

#define PIT_DATA0  0x40
#define PIT_DATA1  0x41
#define PIT_DATA2  0x42
#define PIT_CMD    0x43
#define PIT_FREQ   1193182UL   /* PIT base clock, Hz */

volatile uint64_t g_ticks = 0;     /* incremented on each timer IRQ */

void pit_init(uint32_t hz) {
    if (hz == 0) hz = 100;
    uint32_t divisor = PIT_FREQ / hz;
    if (divisor == 0) divisor = 1;
    if (divisor > 0xFFFF) divisor = 0xFFFF;
    /* Channel 0, lo+hi byte, mode 2 (rate generator), binary */
    outb(PIT_CMD, 0x36);
    outb(PIT_DATA0, divisor & 0xFF);
    outb(PIT_DATA0, (divisor >> 8) & 0xFF);
    /* Unmask IRQ0 (was masked by pic_init) */
    pic_unmask(0);
}

/* Called by idt_dispatch on each timer tick. */
void pit_handler(void) {
    g_ticks++;
    pic_eoi(0);
}

uint64_t pit_ticks(void) {
    uint64_t t;
    __asm__ volatile ("" ::: "memory");
    t = g_ticks;
    return t;
}

void pit_sleep_ms(uint32_t ms) {
    /* Assuming PIT init at 100 Hz: 1 tick = 10 ms */
    uint64_t start = pit_ticks();
    uint64_t need  = (ms + 9) / 10;
    while (pit_ticks() - start < need) {
        __asm__ volatile ("hlt");
    }
}
