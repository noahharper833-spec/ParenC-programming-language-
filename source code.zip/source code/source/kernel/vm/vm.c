/*
 * vm.c - ParenCode virtual machine (kernel-side).
 *
 * Each instruction is 9 bytes: 1 byte opcode + 8 byte little-endian int64
 * operand. Operands are signed two's-complement.
 *
 * Implements all 50 opcodes 0..49.
 *
 * The VM uses a 1 MiB stack and a 64-slot variable table.
 * PRINT writes to the framebuffer console. SHELL drops into the
 * interactive shell (kernel/shell.c).
 *
 * Graphics opcodes call fb_draw_pixel / fb_draw_rect.
 * Sound (BEEP) calls beep_play.
 */
#include "parenos.h"
#include "vm.h"
#include "shell.h"
#include "fb.h"
#include "ps2.h"
#include "beep.h"
#include "wm.h"
#include "rtc.h"
#include "tar.h"

#define VM_STACK_SIZE  (1 << 16)   /* 65536 entries */
#define VM_VARS        256

static int64_t *vstack;
static int      vsp;
static int64_t  vvars[VM_VARS];

static inline int64_t pop(void) {
    if (vsp <= 0) kpanic("VM: stack underflow");
    return vstack[--vsp];
}
static inline void push(int64_t v) {
    if (vsp >= VM_STACK_SIZE) kpanic("VM: stack overflow");
    vstack[vsp++] = v;
}

void vm_run(const uint8_t *code, size_t size) {
    vstack = (int64_t *)kmalloc(VM_STACK_SIZE * sizeof(int64_t));
    if (!vstack) kpanic("VM: cannot allocate stack");
    vsp = 0;
    kmemset(vvars, 0, sizeof(vvars));

    size_t pc = 0;
    int halted = 0;
    uint64_t step_count = 0;
    while (!halted && pc + 9 <= size) {
        uint8_t  op = code[pc];
        int64_t  arg;
        kmemcpy(&arg, code + pc + 1, 8);
        pc += 9;
        switch (op) {
        case 0: /* NOP */
            break;
        case 1: /* PUSH */
            push(arg);
            break;
        case 2: /* POP */
            pop();
            break;
        case 3: /* ADD */
            { int64_t b = pop(), a = pop(); push(a + b); }
            break;
        case 4: /* SUB */
            { int64_t b = pop(), a = pop(); push(a - b); }
            break;
        case 5: /* MUL */
            { int64_t b = pop(), a = pop(); push(a * b); }
            break;
        case 6: /* DIV */
            { int64_t b = pop(), a = pop();
              if (b == 0) kpanic("VM: division by zero");
              int64_t q = a / b;
              push(q);
            }
            break;
        case 7: /* MOD */
            { int64_t b = pop(), a = pop();
              if (b == 0) kpanic("VM: modulo by zero");
              push(a % b);
            }
            break;
        case 8: /* NEG */
            push(-pop());
            break;
        case 9: /* INC */
            push(pop() + 1);
            break;
        case 10: /* DEC */
            push(pop() - 1);
            break;
        case 11: /* EQ */
            { int64_t b = pop(), a = pop(); push(a == b ? 1 : 0); }
            break;
        case 12: /* NE */
            { int64_t b = pop(), a = pop(); push(a != b ? 1 : 0); }
            break;
        case 13: /* LT */
            { int64_t b = pop(), a = pop(); push(a < b ? 1 : 0); }
            break;
        case 14: /* LE */
            { int64_t b = pop(), a = pop(); push(a <= b ? 1 : 0); }
            break;
        case 15: /* GT */
            { int64_t b = pop(), a = pop(); push(a > b ? 1 : 0); }
            break;
        case 16: /* GE */
            { int64_t b = pop(), a = pop(); push(a >= b ? 1 : 0); }
            break;
        case 17: /* JUMP */
            pc = (size_t)arg;
            break;
        case 18: /* JZ */
            { int64_t v = pop(); if (v == 0) pc = (size_t)arg; }
            break;
        case 19: /* JNZ */
            { int64_t v = pop(); if (v != 0) pc = (size_t)arg; }
            break;
        case 20: /* PRINT */
            fb_putdec(pop());
            break;
        case 21: /* NEWLINE */
            fb_putc('\n');
            break;
        case 22: /* SET */
            if (arg < 0 || arg >= VM_VARS) kpanic("VM: SET out of range");
            vvars[arg] = pop();
            break;
        case 23: /* GET */
            if (arg < 0 || arg >= VM_VARS) kpanic("VM: GET out of range");
            push(vvars[arg]);
            break;
        case 24: /* CLEAR */
            if (arg >= 0 && arg < VM_VARS) vvars[arg] = 0;
            break;
        case 25: /* HELP */
            fb_puts("Commands: ls cd pwd mkdir read write delete time sleep random beep about halt\n");
            break;
        case 26: /* SHELL */
            shell_run();
            break;
        case 27: /* MKDIR */
            /* In the kernel VM, mkdir is a no-op on the read-only initramfs. */
            break;
        case 28: /* LS */
            shell_list_files();
            break;
        case 29: /* PWD */
            fb_puts("/\n");
            break;
        case 30: /* CD */
            /* In read-only initramfs, cd is a stub. */
            break;
        case 31: /* READ */
            /* arg = path id (var slot); we read /etc/welcome.txt for slot 0 */
            {
                size_t sz = 0;
                const char *path = (arg == 0) ? "/etc/welcome.txt" : "/etc/welcome.txt";
                const void *data = tar_lookup(path, &sz);
                if (data) {
                    for (size_t i = 0; i < sz; i++) fb_putc(((const char *)data)[i]);
                } else {
                    fb_puts("(file not found)\n");
                }
            }
            break;
        case 32: /* WRITE */
            /* initramfs is read-only; we acknowledge but do nothing. */
            fb_puts("(write: read-only filesystem)\n");
            break;
        case 33: /* DELETE */
            fb_puts("(delete: read-only filesystem)\n");
            break;
        case 34: /* TIME */
            {
                rtc_time_t t;
                rtc_get(&t);
                /* Pack into a 32-bit slot: h*10000 + m*100 + s */
                push((int64_t)(t.hour * 10000 + t.min * 100 + t.sec));
            }
            break;
        case 35: /* SLEEP ms (arg = ms) */
            {
                extern volatile uint64_t g_ticks;
                uint64_t start = g_ticks;
                uint64_t need = (arg + 9) / 10;
                while (g_ticks - start < need) {
                    __asm__ volatile ("hlt");
                }
            }
            break;
        case 36: /* RANDOM */
            {
                /* Simple LCG seeded by ticks. */
                static uint64_t seed = 0;
                if (seed == 0) {
                    extern volatile uint64_t g_ticks;
                    seed = g_ticks | 0x1;
                }
                seed = seed * 6364136223846793005ULL + 1442695040888963407ULL;
                push((int64_t)(seed >> 33) & 0x7FFFFFFF);
            }
            break;
        case 37: /* BEEP */
            beep_play(440, 100);
            break;
        case 38: /* WINDOW (id) */
            wm_init();
            break;
        case 39: /* PIXEL x y color */
            {
                int64_t color = pop();
                int64_t y = pop();
                int64_t x = pop();
                fb_draw_pixel((int)x, (int)y, (uint32_t)color);
            }
            break;
        case 40: /* RECT x y w h color */
            {
                int64_t color = pop();
                int64_t h = pop();
                int64_t w = pop();
                int64_t y = pop();
                int64_t x = pop();
                fb_draw_rect((int)x, (int)y, (int)w, (int)h, (uint32_t)color);
            }
            break;
        case 41: /* CLS_GRAPHICS */
            fb_clear(0, 0, 0);
            break;
        case 42: /* KEY */
            {
                int c = kbd_waitc();
                push(c);
            }
            break;
        case 43: /* MOUSE */
            push(mouse_get_x());
            push(mouse_get_y());
            push(mouse_get_btn());
            break;
        case 44: /* SPAWN */
            /* Single-threaded kernel: cannot truly spawn. */
            fb_puts("(spawn: single-threaded kernel)\n");
            break;
        case 45: /* KILL */
            break;
        case 46: /* SAVE */
            fb_puts("(save: no persistent storage driver)\n");
            break;
        case 47: /* LOAD */
            fb_puts("(load: no persistent storage driver)\n");
            break;
        case 48: /* ABOUT */
            fb_puts("ParenOS - a tiny operating system built in ParenCode.\n");
            fb_puts("Source uses only 4 characters: + / ( )\n");
            break;
        case 49: /* HALT */
            halted = 1;
            break;
        default:
            kpanic("VM: unknown opcode");
        }
        step_count++;
        if (step_count > 100000000ULL) kpanic("VM: step limit exceeded");
    }
}
