/* ps2.h - PS/2 keyboard + mouse */
#ifndef PS2_H
#define PS2_H
#include "parenos.h"

void  ps2_init(void);
void  kbd_handler(void);
int   kbd_getc(void);
int   kbd_waitc(void);
void  mouse_handler(void);
int   mouse_get_x(void);
int   mouse_get_y(void);
uint8_t mouse_get_btn(void);
bool  mouse_poll_event(int *x, int *y, uint8_t *btn);

#endif
