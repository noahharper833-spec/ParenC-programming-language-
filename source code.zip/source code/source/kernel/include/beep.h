#ifndef BEEP_H
#define BEEP_H
#include "parenos.h"

void beep_init(void);
void beep_on(uint32_t freq);
void beep_off(void);
void beep_play(uint32_t freq, uint32_t ms);

#endif
