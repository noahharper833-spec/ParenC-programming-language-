#ifndef RTC_H
#define RTC_H
#include "parenos.h"

typedef struct {
    uint16_t year;
    uint8_t  month, day, hour, min, sec;
} rtc_time_t;

void rtc_init(void);
void rtc_get(rtc_time_t *t);

#endif
