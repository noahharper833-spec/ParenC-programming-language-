/* vm.h - ParenCode VM interface */
#ifndef VM_H
#define VM_H
#include "parenos.h"

void vm_run(const uint8_t *bytecode, size_t size);

#endif
