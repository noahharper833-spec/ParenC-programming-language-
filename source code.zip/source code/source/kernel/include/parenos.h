/*
 * parenos.h - central kernel header.
 */
#ifndef PARENOS_H
#define PARENOS_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

/* Compile-time integer helpers */
#define PARENOS_ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

/* Kernel entry point (called from multiboot2.S) */
void kmain(uint64_t mb2_info);

/* Panic with a message. */
__attribute__((noreturn))
void kpanic(const char *msg);

/* Various subsystem init */
void gdt_init(void);
void idt_init(void);
void pic_init(void);
void pit_init(uint32_t hz);
void irq_enable(void);
void irq_disable(void);

/* Console / framebuffer */
void fb_init(uint64_t mb2_info);
void fb_clear(uint8_t r, uint8_t g, uint8_t b);
void fb_putc(char c);
void fb_puts(const char *s);
void fb_putdec(int64_t v);
void fb_putuint(uint64_t v);
void fb_puthex(uint64_t v);
void fb_set_cursor(int x, int y);
void fb_newline(void);
void fb_backspace(void);
void fb_scroll(int lines);
void fb_set_color(uint32_t fg, uint32_t bg);
int  fb_cols(void);
int  fb_rows(void);

/* Framebuffer drawing primitives */
typedef struct {
    uint32_t *buf;
    uint32_t  width;
    uint32_t  height;
    uint32_t  pitch;     /* bytes per row */
    uint8_t   bpp;
    uint8_t   type;      /* 1=indexed, 2=RGB */
    uint8_t   r_pos, r_mask;
    uint8_t   g_pos, g_mask;
    uint8_t   b_pos, b_mask;
} framebuffer_t;

extern framebuffer_t g_fb;

void fb_draw_pixel(int x, int y, uint32_t color);
void fb_draw_rect(int x, int y, int w, int h, uint32_t color);
void fb_draw_hline(int x, int y, int w, uint32_t color);
void fb_draw_vline(int x, int y, int h, uint32_t color);
void fb_draw_text(int x, int y, const char *s, uint32_t fg, uint32_t bg);
uint32_t fb_make_color(uint8_t r, uint8_t g, uint8_t b);

/* Heap */
void heap_init(void *start, size_t size);
void *kmalloc(size_t n);
void *kzalloc(size_t n);
void  kfree(void *p);
void  kmemset(void *p, int v, size_t n);
void  kmemcpy(void *dst, const void *src, size_t n);
size_t kstrlen(const char *s);
int   kstrcmp(const char *a, const char *b);
int   kstrncmp(const char *a, const char *b, size_t n);
char *kstrcpy(char *dst, const char *src);
char *kstrcat(char *dst, const char *src);
char *kstrncpy(char *dst, const char *src, size_t n);
int   kstoi(const char *s, char **end);

/* Serial */
void serial_init(void);
void serial_putc(char c);
char serial_getc(void);
int  serial_write(const char *buf, size_t n);

/* Multiboot2 info parsing */
void mb2_parse(uint64_t mb2_info);
const framebuffer_t *mb2_get_framebuffer(void);
const void *mb2_get_module(uint64_t *out_size, const char *name_prefix);

/* IDT helpers */
void idt_set_gate(int n, void (*handler)(void), uint8_t type);
void irq_register(int irq, void (*handler)(void));
void irq_eoi(int irq);
void pic_init(void);
void pic_mask(int irq);
void pic_unmask(int irq);
void pic_eoi(int irq);

/* IRQ handlers (forward declarations so idt_dispatch can call them) */
void pit_handler(void);
void kbd_handler(void);
void serial_handler(void);
void mouse_handler(void);

/* CPU helpers */
static inline void outb(uint16_t port, uint8_t v) {
    __asm__ volatile ("outb %0, %1" :: "a"(v), "Nd"(port));
}
static inline uint8_t inb(uint16_t port) {
    uint8_t v;
    __asm__ volatile ("inb %1, %0" : "=a"(v) : "Nd"(port));
    return v;
}
static inline void outw(uint16_t port, uint16_t v) {
    __asm__ volatile ("outw %0, %1" :: "a"(v), "Nd"(port));
}
static inline uint16_t inw(uint16_t port) {
    uint16_t v;
    __asm__ volatile ("inw %1, %0" : "=a"(v) : "Nd"(port));
    return v;
}
static inline void outl(uint16_t port, uint32_t v) {
    __asm__ volatile ("outl %0, %1" :: "a"(v), "Nd"(port));
}
static inline uint32_t inl(uint16_t port) {
    uint32_t v;
    __asm__ volatile ("inl %1, %0" : "=a"(v) : "Nd"(port));
    return v;
}
static inline uint64_t read_msr(uint32_t msr) {
    uint32_t lo, hi;
    __asm__ volatile ("rdmsr" : "=a"(lo), "=d"(hi) : "c"(msr));
    return ((uint64_t)hi << 32) | lo;
}
static inline void write_msr(uint32_t msr, uint64_t v) {
    __asm__ volatile ("wrmsr" :: "a"((uint32_t)v), "d"((uint32_t)(v >> 32)), "c"(msr));
}
static inline uint64_t rdtsc(void) {
    uint32_t lo, hi;
    __asm__ volatile ("rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
}
static inline void irq_save(uint64_t *f) {
    __asm__ volatile ("pushfq; popq %0; cli" : "=m"(*f));
}
static inline void irq_restore(uint64_t f) {
    __asm__ volatile ("pushq %0; popfq" :: "m"(f));
}
static inline void cpu_halt(void) {
    __asm__ volatile ("hlt");
}

#endif /* PARENOS_H */
