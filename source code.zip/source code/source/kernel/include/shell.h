/* shell.h - interactive shell */
#ifndef SHELL_H
#define SHELL_H
void shell_run(void);
void shell_list_files(void);
#endif
