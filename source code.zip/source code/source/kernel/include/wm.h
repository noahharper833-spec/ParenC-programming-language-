/* wm.h - window manager + desktop + apps */
#ifndef WM_H
#define WM_H
#include "parenos.h"

void wm_init(void);
void wm_redraw(void);
void wm_dispatch_mouse(int x, int y, uint8_t btn);
void wm_dispatch_key(int ch);

/* Apps */
void app_terminal(void);
void app_file_manager(void);
void app_editor_open(const char *path);
void app_calculator(void);
void app_about(void);

#endif
