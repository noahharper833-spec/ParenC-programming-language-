#ifndef FONT_H
#define FONT_H
#include "parenos.h"

void font_init(void);
void font_draw_glyph(char c, int x, int y, uint32_t fg, uint32_t bg);
void font_draw_text(const char *s, int x, int y, uint32_t fg, uint32_t bg);

#endif
