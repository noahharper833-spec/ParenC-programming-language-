/* tar.h - initramfs tar interface */
#ifndef TAR_H
#define TAR_H
#include "parenos.h"

int tar_init(const void *ramdisk);
const void *tar_lookup(const char *path, size_t *out_size);
void tar_enumerate(void (*cb)(const char *path, size_t size, void *u), void *u);

#endif
