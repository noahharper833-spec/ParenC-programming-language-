/* fb.h - framebuffer + console */
#ifndef FB_H
#define FB_H
#include "parenos.h"
#endif
