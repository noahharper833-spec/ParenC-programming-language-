/*
 * wm.c - ParenOS window manager + desktop + applications.
 *
 * A small compositing window manager. Each window has:
 *   - a position (x, y) and size (w, h)
 *   - a title bar with a close button
 *   - a content area (rendered by the app)
 *
 * The mouse cursor is drawn as an XOR-composited arrow so that it
 * never permanently paints the framebuffer - we save and restore the
 * pixels under it.
 *
 * Apps included:
 *   - About:        shows OS info
 *   - Calculator:   simple stack calculator (digits + - * / =)
 *   - File manager: lists initramfs files
 *   - Editor:       opens and displays a file (read-only)
 */
#include "parenos.h"
#include "wm.h"
#include "fb.h"
#include "ps2.h"
#include "font.h"
#include "tar.h"
#include "rtc.h"
#include "beep.h"

#define MAX_WINDOWS 16

typedef struct {
    int      x, y, w, h;
    char     title[40];
    int      used;
    void   (*draw)(int x, int y, int w, int h);
} window_t;

static window_t windows[MAX_WINDOWS];
static int      wm_inited = 0;

/* Saved pixels under the mouse cursor (16x16). */
static uint32_t cursor_saved[16 * 16];
static int      cursor_saved_x = -1, cursor_saved_y = -1;

/* Mouse cursor arrow shape (16x16). */
static const uint8_t cursor_shape[16] = {
    0x80, 0xC0, 0xE0, 0xF0, 0xF8, 0xFC, 0xFE, 0xFF,
    0xFC, 0x4C, 0x0C, 0x00, 0x00, 0x00, 0x00, 0x00,
};

static void cursor_save(int x, int y) {
    for (int dy = 0; dy < 16; dy++) {
        for (int dx = 0; dx < 16; dx++) {
            int px = x + dx, py = y + dy;
            if (px < 0 || py < 0 || (uint32_t)px >= g_fb.width || (uint32_t)py >= g_fb.height) {
                cursor_saved[dy * 16 + dx] = 0;
                continue;
            }
            cursor_saved[dy * 16 + dx] = g_fb.buf[py * (g_fb.pitch / 4) + px];
        }
    }
}

static void cursor_restore(int x, int y) {
    for (int dy = 0; dy < 16; dy++) {
        for (int dx = 0; dx < 16; dx++) {
            int px = x + dx, py = y + dy;
            if (px < 0 || py < 0 || (uint32_t)px >= g_fb.width || (uint32_t)py >= g_fb.height) continue;
            g_fb.buf[py * (g_fb.pitch / 4) + px] = cursor_saved[dy * 16 + dx];
        }
    }
}

static void cursor_draw(int x, int y) {
    for (int dy = 0; dy < 16; dy++) {
        uint8_t bits = cursor_shape[dy];
        for (int dx = 0; dx < 8; dx++) {
            if (bits & (0x80 >> dx)) {
                int px = x + dx, py = y + dy;
                if (px < 0 || py < 0 || (uint32_t)px >= g_fb.width || (uint32_t)py >= g_fb.height) continue;
                uint32_t cur = g_fb.buf[py * (g_fb.pitch / 4) + px];
                /* XOR with white so the cursor is visible on any background. */
                g_fb.buf[py * (g_fb.pitch / 4) + px] = cur ^ 0x00FFFFFF;
            }
        }
    }
}

static void wm_draw_cursor(void) {
    int x = mouse_get_x();
    int y = mouse_get_y();
    if (cursor_saved_x >= 0) cursor_restore(cursor_saved_x, cursor_saved_y);
    cursor_save(x, y);
    cursor_draw(x, y);
    cursor_saved_x = x;
    cursor_saved_y = y;
}

static void wm_draw_desktop(void) {
    /* Solid dark blue background */
    fb_draw_rect(0, 0, g_fb.width, g_fb.height, fb_make_color(20, 30, 60));
    /* Title bar at top */
    fb_draw_rect(0, 0, g_fb.width, 24, fb_make_color(40, 60, 100));
    font_draw_text("ParenOS Desktop", 8, 4, fb_make_color(255, 255, 255), fb_make_color(40, 60, 100));
    /* Bottom status bar */
    int sy = g_fb.height - 24;
    fb_draw_rect(0, sy, g_fb.width, 24, fb_make_color(40, 60, 100));
    font_draw_text("a=About c=Calculator f=Files e=Editor ESC=Exit", 8, sy + 4,
                   fb_make_color(220, 220, 220), fb_make_color(40, 60, 100));
}

static void wm_draw_window(window_t *w) {
    /* Window background */
    fb_draw_rect(w->x, w->y, w->w, w->h, fb_make_color(230, 230, 230));
    /* Title bar */
    fb_draw_rect(w->x, w->y, w->w, 18, fb_make_color(80, 120, 200));
    font_draw_text(w->title, w->x + 6, w->y + 2, fb_make_color(255, 255, 255), fb_make_color(80, 120, 200));
    /* Close button [X] */
    font_draw_text("[X]", w->x + w->w - 26, w->y + 2,
                   fb_make_color(255, 255, 255), fb_make_color(200, 60, 60));
    /* Borders */
    fb_draw_hline(w->x, w->y + w->h - 1, w->w, fb_make_color(60, 80, 120));
    fb_draw_vline(w->x, w->y, w->h, fb_make_color(60, 80, 120));
    fb_draw_vline(w->x + w->w - 1, w->y, w->h, fb_make_color(60, 80, 120));
    /* Content */
    if (w->draw) w->draw(w->x, w->y + 18, w->w, w->h - 18);
}

void wm_redraw(void) {
    if (cursor_saved_x >= 0) cursor_restore(cursor_saved_x, cursor_saved_y);
    cursor_saved_x = -1;
    wm_draw_desktop();
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (windows[i].used) wm_draw_window(&windows[i]);
    }
    wm_draw_cursor();
}

static int wm_create_window(int x, int y, int w, int h, const char *title,
                             void (*draw)(int, int, int, int)) {
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (!windows[i].used) {
            windows[i].x = x; windows[i].y = y; windows[i].w = w; windows[i].h = h;
            windows[i].draw = draw;
            windows[i].used = 1;
            kstrncpy(windows[i].title, title, sizeof(windows[i].title) - 1);
            windows[i].title[sizeof(windows[i].title) - 1] = 0;
            return i;
        }
    }
    return -1;
}

static void wm_destroy_window(int idx) {
    if (idx < 0 || idx >= MAX_WINDOWS) return;
    windows[idx].used = 0;
}

/* ---- App: About ---- */
static void about_draw(int x, int y, int w, int h) {
    (void)w; (void)h;
    font_draw_text("ParenOS v1.0", x + 8, y + 8, 0x000000, fb_make_color(230, 230, 230));
    font_draw_text("A tiny operating system", x + 8, y + 24, 0x000000, fb_make_color(230, 230, 230));
    font_draw_text("written in ParenCode.", x + 8, y + 40, 0x000000, fb_make_color(230, 230, 230));
    font_draw_text("Source chars: + / ( )", x + 8, y + 56, 0x000000, fb_make_color(230, 230, 230));
    font_draw_text("50 opcodes, 4 characters.", x + 8, y + 72, 0x000000, fb_make_color(230, 230, 230));
    font_draw_text("Boots on x86_64 via GRUB.", x + 8, y + 88, 0x000000, fb_make_color(230, 230, 230));
}

void app_about(void) {
    wm_create_window(120, 60, 360, 140, "About", about_draw);
    wm_redraw();
}

/* ---- App: Calculator ---- */
static char calc_display[64];
static int64_t calc_a = 0, calc_b = 0;
static char  calc_op = 0;
static int   calc_state = 0;

static void calc_format(int64_t v, char *out) {
    char tmp[24]; int t = 0;
    int neg = 0;
    if (v < 0) { neg = 1; v = -v; }
    if (v == 0) tmp[t++] = '0';
    while (v > 0) { tmp[t++] = '0' + (v % 10); v /= 10; }
    int o = 0;
    if (neg) out[o++] = '-';
    while (t > 0) out[o++] = tmp[--t];
    out[o] = 0;
}

static void calc_draw(int x, int y, int w, int h) {
    (void)w; (void)h;
    fb_draw_rect(x + 4, y + 4, 240, 28, fb_make_color(200, 220, 200));
    char buf[64];
    if (calc_state == 0) calc_format(calc_a, buf);
    else calc_format(calc_b, buf);
    font_draw_text(buf, x + 12, y + 10, 0x000000, fb_make_color(200, 220, 200));
    font_draw_text("Digits: 0-9  Op: + - * /", x + 8, y + 40, fb_make_color(40, 40, 40), fb_make_color(230, 230, 230));
    font_draw_text("=  compute   c  clear", x + 8, y + 56, fb_make_color(40, 40, 40), fb_make_color(230, 230, 230));
    font_draw_text("ESC to close", x + 8, y + 72, fb_make_color(40, 40, 40), fb_make_color(230, 230, 230));
    if (calc_op) {
        char op_text[24];
        op_text[0] = 'o'; op_text[1] = 'p'; op_text[2] = ':';
        op_text[3] = ' '; op_text[4] = calc_op; op_text[5] = 0;
        font_draw_text(op_text, x + 8, y + 88, fb_make_color(60, 0, 0), fb_make_color(230, 230, 230));
    }
}

static void calc_compute(void) {
    switch (calc_op) {
    case '+': calc_a = calc_a + calc_b; break;
    case '-': calc_a = calc_a - calc_b; break;
    case '*': calc_a = calc_a * calc_b; break;
    case '/': if (calc_b != 0) calc_a = calc_a / calc_b; else calc_a = 0; break;
    default: return;
    }
    calc_b = 0;
    calc_op = 0;
    calc_state = 0;
}

void app_calculator(void) {
    int win = wm_create_window(200, 80, 260, 130, "Calculator", calc_draw);
    wm_redraw();
    calc_a = 0; calc_b = 0; calc_op = 0; calc_state = 0;
    for (;;) {
        int c = kbd_waitc();
        if (c == 27) { wm_destroy_window(win); wm_redraw(); return; }
        if (c >= '0' && c <= '9') {
            int d = c - '0';
            if (calc_state == 0) calc_a = calc_a * 10 + d;
            else calc_b = calc_b * 10 + d;
        } else if (c == '+' || c == '-' || c == '*' || c == '/') {
            if (calc_state == 1 && calc_op) calc_compute();
            calc_op = c;
            calc_state = 1;
        } else if (c == '=' || c == '\n' || c == '\r') {
            calc_compute();
        } else if (c == 'c' || c == 'C') {
            calc_a = 0; calc_b = 0; calc_op = 0; calc_state = 0;
        }
        wm_redraw();
    }
}

/* ---- App: File Manager ---- */
static int files_row_y;
static int files_origin_x, files_origin_y, files_max_x, files_max_y;
static void files_list_cb(const char *path, size_t size, void *u) {
    (void)u; (void)size;
    if (files_row_y + 16 < files_max_y) {
        font_draw_text(path, files_origin_x, files_origin_y + files_row_y,
                       0x000000, fb_make_color(230, 230, 230));
        files_row_y += 16;
    }
}

static void files_draw(int x, int y, int w, int h) {
    font_draw_text("Initramfs contents:", x + 8, y + 4, 0x000000, fb_make_color(230, 230, 230));
    files_origin_x = x + 12;
    files_origin_y = y + 24;
    files_max_x    = x + w - 8;
    files_max_y    = y + h - 8;
    files_row_y    = 0;
    tar_enumerate(files_list_cb, NULL);
}

void app_file_manager(void) {
    int win = wm_create_window(60, 60, 700, 460, "File Manager", files_draw);
    wm_redraw();
    for (;;) {
        int c = kbd_waitc();
        if (c == 27) { wm_destroy_window(win); wm_redraw(); return; }
    }
}

/* ---- App: Editor (read-only view of a file) ---- */
static const char *editor_data = NULL;
static size_t      editor_size  = 0;

static void editor_draw(int x, int y, int w, int h) {
    if (!editor_data) {
        font_draw_text("(empty)", x + 8, y + 4, fb_make_color(60, 60, 60), fb_make_color(230, 230, 230));
        return;
    }
    int cx = x + 4, cy = y + 4;
    int max_x = x + w - 8;
    int max_y = y + h - 8;
    for (size_t i = 0; i < editor_size; i++) {
        char c = editor_data[i];
        if (c == '\n') { cx = x + 4; cy += 16; if (cy >= max_y) break; continue; }
        if (c == '\r') continue;
        if (c == '\t') { cx += 32; continue; }
        if (cx + 8 > max_x) { cx = x + 4; cy += 16; if (cy >= max_y) break; }
        font_draw_glyph(c, cx, cy, 0x000000, fb_make_color(230, 230, 230));
        cx += 8;
    }
}

void app_editor_open(const char *path) {
    size_t sz = 0;
    const void *p = tar_lookup(path, &sz);
    if (!p) {
        editor_data = "(file not found)";
        editor_size = kstrlen(editor_data);
    } else {
        editor_data = (const char *)p;
        editor_size = sz;
    }
    int win = wm_create_window(40, 50, 800, 500, path ? path : "Editor", editor_draw);
    wm_redraw();
    for (;;) {
        int c = kbd_waitc();
        if (c == 27) { wm_destroy_window(win); wm_redraw(); return; }
    }
}

/* ---- App: Terminal (full-screen shortcut) ---- */
void app_terminal(void) {
    fb_clear(0, 0, 0);
    fb_set_cursor(0, 0);
    fb_set_color(0x55FF55, 0x000000);
    fb_puts("ParenOS Terminal\n");
    fb_set_color(0xEEEEEE, 0x000000);
    fb_puts("Type 'help' for commands. ESC to return to desktop.\n");
    for (;;) {
        int c = kbd_waitc();
        if (c == 27) { wm_redraw(); return; }
        fb_putc((char)c);
    }
}

/* ---- Window manager main loop ---- */
void wm_init(void) {
    if (!wm_inited) {
        for (int i = 0; i < MAX_WINDOWS; i++) windows[i].used = 0;
        wm_inited = 1;
    }
    wm_redraw();
    /* Event loop: poll mouse + keyboard. Exit on ESC. */
    for (;;) {
        int mx, my;
        uint8_t mb;
        if (mouse_poll_event(&mx, &my, &mb)) {
            wm_redraw();
        }
        int k = kbd_getc();
        if (k == 27) {
            /* Exit desktop, go back to shell */
            fb_clear(0, 0, 0);
            fb_set_cursor(0, 0);
            fb_set_color(0xCCCCCC, 0x000000);
            return;
        }
        if (k == 'a' || k == 'A') app_about();
        else if (k == 'c' || k == 'C') app_calculator();
        else if (k == 'f' || k == 'F') app_file_manager();
        else if (k == 'e' || k == 'E') app_editor_open("/source/parenos.par");
        else if (k == 't' || k == 'T') app_terminal();
        __asm__ volatile ("hlt");
    }
}
