/*
 * shell.c - ParenOS interactive shell.
 *
 * The shell presents a colored prompt on the framebuffer console and
 * accepts commands like `ls`, `pwd`, `about`, `time`, `beep`, `calc`,
 * `editor`, `files`, `clear`, `halt`. It reads characters from the
 * PS/2 keyboard via kbd_waitc().
 *
 * The shell is launched either by the ParenCode VM after the .par
 * program returns, or directly by the kernel if no .par program is
 * present in the initramfs.
 */
#include "parenos.h"
#include "shell.h"
#include "fb.h"
#include "ps2.h"
#include "tar.h"
#include "rtc.h"
#include "beep.h"
#include "wm.h"
#include "font.h"

#define CMD_MAX 256
static char cmd_buf[CMD_MAX];
static int  cmd_len = 0;

static void shell_list_cb(const char *path, size_t size, void *u);

static void shell_prompt(void) {
    fb_set_color(0x55FF55, 0x000000);
    fb_puts("parenos");
    fb_set_color(0xAAAAAA, 0x000000);
    fb_puts(":");
    fb_set_color(0x55AAFF, 0x000000);
    fb_puts("/");
    fb_set_color(0xAAAAAA, 0x000000);
    fb_puts("$ ");
    fb_set_color(0xEEEEEE, 0x000000);
}

static void shell_help(void) {
    fb_puts(
        "ParenOS shell commands:\n"
        "  help      - show this help\n"
        "  about     - about ParenOS\n"
        "  ls        - list files in initramfs\n"
        "  cat PATH  - print a file from the initramfs\n"
        "  pwd       - print current directory (always /)\n"
        "  echo TXT  - print TXT\n"
        "  time      - print current RTC time\n"
        "  date      - print current RTC date\n"
        "  beep      - emit a short beep\n"
        "  calc      - launch calculator\n"
        "  editor    - launch text editor\n"
        "  files     - launch file manager\n"
        "  desktop   - launch the desktop (window manager)\n"
        "  clear     - clear the screen\n"
        "  halt      - power off / halt the system\n"
    );
}

static void shell_about(void) {
    fb_puts(
        "ParenOS v1.0 - a tiny operating system written in ParenCode.\n"
        "Source language uses only 4 characters: + / ( )\n"
        "Bootable x86_64 ISO booted by GRUB; kernel in C; VM in C.\n"
    );
}

static void print_uint(int x) {
    if (x < 10) { fb_putc('0' + x); return; }
    print_uint(x / 10);
    fb_putc('0' + (x % 10));
}

static void shell_time(void) {
    rtc_time_t t;
    rtc_get(&t);
    if (t.hour < 10) fb_putc('0');
    fb_putuint(t.hour); fb_putc(':');
    if (t.min < 10) fb_putc('0');
    fb_putuint(t.min); fb_putc(':');
    if (t.sec < 10) fb_putc('0');
    fb_putuint(t.sec);
    fb_putc('\n');
}

static void shell_date(void) {
    rtc_time_t t;
    rtc_get(&t);
    fb_putuint(t.year); fb_putc('-');
    if (t.month < 10) fb_putc('0');
    fb_putuint(t.month); fb_putc('-');
    if (t.day < 10) fb_putc('0');
    fb_putuint(t.day);
    fb_putc('\n');
}

void shell_list_files(void) {
    /* Use a static file-pointer-as-context trick since tar_enumerate
     * uses a plain callback. */
    tar_enumerate(shell_list_cb, NULL);
}

static void shell_list_cb(const char *path, size_t size, void *u) {
    (void)u; (void)size;
    fb_puts(path);
    fb_putc('\n');
}

static void shell_cat(const char *path) {
    size_t sz = 0;
    const void *p = tar_lookup(path, &sz);
    if (!p) {
        fb_puts("cat: ");
        fb_puts(path);
        fb_puts(": not found\n");
        return;
    }
    const char *s = (const char *)p;
    for (size_t i = 0; i < sz; i++) fb_putc(s[i]);
}

static void shell_execute(const char *line) {
    if (cmd_len == 0) return;
    /* Tokenize: split off the first word. */
    int i = 0;
    while (line[i] == ' ') i++;
    int start = i;
    while (line[i] && line[i] != ' ') i++;
    int wlen = i - start;
    /* Find first argument. */
    while (line[i] == ' ') i++;
    const char *arg = line + i;
    (void)arg;

    if (wlen == 4 && kstrncmp(line + start, "help", 4) == 0) {
        shell_help();
    } else if (wlen == 5 && kstrncmp(line + start, "about", 5) == 0) {
        shell_about();
    } else if (wlen == 2 && kstrncmp(line + start, "ls", 2) == 0) {
        shell_list_files();
    } else if (wlen == 3 && kstrncmp(line + start, "pwd", 3) == 0) {
        fb_puts("/\n");
    } else if (wlen == 3 && kstrncmp(line + start, "cat", 3) == 0) {
        shell_cat(arg);
    } else if (wlen == 4 && kstrncmp(line + start, "echo", 4) == 0) {
        fb_puts(arg);
        fb_putc('\n');
    } else if (wlen == 4 && kstrncmp(line + start, "time", 4) == 0) {
        shell_time();
    } else if (wlen == 4 && kstrncmp(line + start, "date", 4) == 0) {
        shell_date();
    } else if (wlen == 4 && kstrncmp(line + start, "beep", 4) == 0) {
        beep_play(880, 150);
    } else if (wlen == 4 && kstrncmp(line + start, "calc", 4) == 0) {
        app_calculator();
    } else if (wlen == 6 && kstrncmp(line + start, "editor", 6) == 0) {
        app_editor_open(arg && *arg ? arg : "/source/parenos.par");
    } else if (wlen == 5 && kstrncmp(line + start, "files", 5) == 0) {
        app_file_manager();
    } else if (wlen == 7 && kstrncmp(line + start, "desktop", 7) == 0) {
        wm_init();
    } else if (wlen == 5 && kstrncmp(line + start, "clear", 5) == 0) {
        fb_clear(0, 0, 0);
        fb_set_cursor(0, 0);
    } else if (wlen == 4 && kstrncmp(line + start, "halt", 4) == 0) {
        fb_set_color(0xFF5555, 0x000000);
        fb_puts("\nSystem halt requested. Goodbye.\n");
        for (;;) { __asm__ volatile ("cli; hlt"); }
    } else {
        fb_puts("unknown command: ");
        fb_puts(line + start);
        fb_putc('\n');
    }
}

void shell_run(void) {
    irq_enable();
    fb_puts("\nParenOS Shell. Type 'help' for commands.\n\n");
    cmd_len = 0;
    shell_prompt();
    for (;;) {
        int c = kbd_waitc();
        if (c == '\r' || c == '\n') {
            fb_putc('\n');
            cmd_buf[cmd_len] = 0;
            shell_execute(cmd_buf);
            cmd_len = 0;
            shell_prompt();
        } else if (c == 8) {
            if (cmd_len > 0) {
                cmd_len--;
                fb_backspace();
            }
        } else if (c >= 32 && c < 127 && cmd_len < CMD_MAX - 1) {
            cmd_buf[cmd_len++] = (char)c;
            fb_putc((char)c);
        }
    }
}
